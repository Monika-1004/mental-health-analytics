import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.utils import resample
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
import warnings
warnings.filterwarnings("ignore")

st.set_page_config(
    page_title="Teen Mental Health · AI Dashboard",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Instrument+Serif:ital@0;1&display=swap');

/* ── Hide Streamlit chrome ── */
header[data-testid="stHeader"],
#MainMenu,
[data-testid="stToolbar"],
.stDeployButton { display:none !important; }

/* ── Viewport lock ── */
html, body { overflow:hidden !important; height:100vh !important; background:#f8f7ff !important; }
[data-testid="stAppViewContainer"],
[data-testid="stMain"] { height:100vh !important; overflow:hidden !important; background:#f8f7ff !important; }
.block-container {
    height:100vh !important; overflow:hidden !important;
    padding:1.2rem 2rem 0 !important;
    background:#f8f7ff !important;
}
[data-testid="stTabsContent"] {
    overflow-y:auto !important;
    max-height:calc(100vh - 115px) !important;
    padding-bottom:2rem !important;
}
[data-testid="stSidebar"] { overflow-y:auto !important; }

/* ── Typography ── */
html, body, [class*="css"] { font-family:'Plus Jakarta Sans', sans-serif !important; }

/* ── Sidebar ── */
[data-testid="stSidebar"] {
    background: #ffffff !important;
    border-right: 1.5px solid #ede9fe !important;
}
[data-testid="stSidebar"] * { color: #3b2f6b !important; }
[data-testid="stSidebar"] .stSlider > div > div > div { background: #7c3aed !important; }
[data-testid="stSidebar"] hr { border-color: #ede9fe !important; }
[data-testid="stSidebar"] label { color:#6d5c99 !important; font-size:0.82rem !important; }

/* ── Main background ── */
[data-testid="stAppViewContainer"] { background: #f8f7ff !important; }

/* ── Tab bar ── */
[data-testid="stTabs"] > div:first-child {
    background: #ffffff !important;
    border-radius: 14px !important;
    padding: 4px !important;
    border: 1.5px solid #ede9fe !important;
    gap: 4px !important;
    box-shadow: 0 2px 12px rgba(124,58,237,0.06) !important;
}
button[data-baseweb="tab"] {
    font-family:'Plus Jakarta Sans', sans-serif !important;
    font-weight:600 !important;
    font-size:0.82rem !important;
    border-radius:10px !important;
    padding:6px 18px !important;
    color:#7c3aed !important;
    background:transparent !important;
    border:none !important;
}
button[data-baseweb="tab"][aria-selected="true"] {
    background:linear-gradient(135deg,#7c3aed,#6d28d9) !important;
    color:#fff !important;
    box-shadow:0 3px 12px rgba(124,58,237,0.25) !important;
}
[data-testid="stTabsContent"] { border:none !important; padding-top:1rem !important; }

/* ── Metric cards ── */
[data-testid="stMetric"] {
    background: #ffffff !important;
    border: 1.5px solid #ede9fe !important;
    border-radius: 14px !important;
    padding: 1rem 1.2rem !important;
    box-shadow: 0 2px 10px rgba(124,58,237,0.06) !important;
}
[data-testid="stMetricLabel"] { color:#7c3aed !important; font-size:0.72rem !important; font-weight:600 !important; letter-spacing:0.06em !important; text-transform:uppercase !important; }
[data-testid="stMetricValue"] { color:#1e1245 !important; font-family:'Plus Jakarta Sans',sans-serif !important; font-size:1.7rem !important; font-weight:800 !important; }
[data-testid="stMetricDelta"] { font-size:0.78rem !important; }

/* ── Section headers ── */
.sec-hdr {
    font-family:'Plus Jakarta Sans',sans-serif;
    font-size:0.7rem;
    font-weight:700;
    letter-spacing:0.13em;
    text-transform:uppercase;
    color:#7c3aed;
    margin:1.1rem 0 0.45rem;
    padding-left:10px;
    border-left:3px solid #c4b5fd;
}
.page-title {
    font-family:'Plus Jakarta Sans',sans-serif;
    font-size:1.55rem;
    font-weight:800;
    color:#1e1245;
    margin-bottom:0.1rem;
}
.page-title span { color:#7c3aed; }
.page-sub { color:#9585c4; font-size:0.82rem; margin-bottom:1rem; }

/* ── Prediction result cards ── */
.pred-safe {
    background:linear-gradient(135deg,#f0fdf4,#dcfce7);
    border:1.5px solid #86efac;
    border-radius:16px; padding:1.5rem 2rem; text-align:center;
}
.pred-risk {
    background:linear-gradient(135deg,#fff1f2,#ffe4e6);
    border:1.5px solid #fca5a5;
    border-radius:16px; padding:1.5rem 2rem; text-align:center;
}
.pred-label { font-family:'Plus Jakarta Sans',sans-serif; font-size:1.7rem; font-weight:800; }
.pred-conf { font-size:0.88rem; margin-top:0.3rem; color:#4b5563; }
.risk-badge {
    display:inline-block; border-radius:8px; padding:3px 12px;
    font-size:0.72rem; font-weight:700; letter-spacing:0.06em;
    text-transform:uppercase; margin-top:0.5rem;
}

/* ── Awaiting card ── */
.await-card {
    background:#ffffff;
    border:1.5px dashed #c4b5fd;
    border-radius:16px; padding:2.5rem; text-align:center; margin-top:1rem;
}

/* ── Expander ── */
[data-testid="stExpander"] {
    border:1.5px solid #ede9fe !important;
    border-radius:12px !important;
    background:#ffffff !important;
}

/* ── Info box ── */
[data-testid="stInfo"] {
    background:#f5f3ff !important;
    border-left:3px solid #7c3aed !important;
    border-radius:8px !important;
    color:#3b2f6b !important;
}

/* ── Slider labels ── */
[data-testid="stSlider"] label,
[data-testid="stSlider"] p,
[data-testid="stSlider"] > label,
div[data-testid="stSlider"] > div > label {
    color:#1e1245 !important;
    font-size:0.82rem !important;
    font-weight:600 !important;
    opacity:1 !important;
    visibility:visible !important;
    display:block !important;
}
/* Slider track and thumb */
[data-testid="stSlider"] [data-baseweb="slider"] [role="slider"] {
    background:#7c3aed !important;
    border-color:#7c3aed !important;
}
[data-testid="stSlider"] [data-baseweb="slider"] div[class*="track"] {
    background:#7c3aed !important;
}
/* Slider value number */
[data-testid="stSlider"] div[data-testid="stTickBarMin"],
[data-testid="stSlider"] div[data-testid="stTickBarMax"] {
    color:#9585c4 !important;
}

/* ── Selectbox / multiselect ── */
[data-testid="stSelectbox"] > div > div,
[data-testid="stMultiSelect"] > div > div {
    background:#ffffff !important;
    border:1.5px solid #ede9fe !important;
    border-radius:10px !important;
    color:#1e1245 !important;
}
[data-testid="stSelectbox"] label,
[data-testid="stMultiSelect"] label {
    color:#1e1245 !important;
    font-size:0.82rem !important;
    font-weight:600 !important;
}

/* ── Buttons ── */
.stButton > button {
    background: linear-gradient(135deg,#7c3aed,#6d28d9) !important;
    color: #ffffff !important;
    border: none !important;
    border-radius: 12px !important;
    font-weight: 700 !important;
    font-size: 0.9rem !important;
    padding: 0.6rem 1rem !important;
    box-shadow: 0 4px 14px rgba(124,58,237,0.3) !important;
}
.stButton > button:hover { opacity:0.9 !important; }
</style>
""", unsafe_allow_html=True)

# ── Constants ──────────────────────────────────────────────────────────────────
NUMERICAL_COLS = ['age','daily_social_media_hours','sleep_hours','screen_time_before_sleep',
                  'academic_performance','physical_activity','stress_level','anxiety_level','addiction_level']
CATEGORICAL_COLS = ['gender','platform_usage','social_interaction_level']
LABEL_MAP = {
    'age':'Age','daily_social_media_hours':'Daily Social Media (hrs)',
    'sleep_hours':'Sleep Hours','screen_time_before_sleep':'Screen Before Sleep (hrs)',
    'academic_performance':'Academic Performance','physical_activity':'Physical Activity',
    'stress_level':'Stress Level','anxiety_level':'Anxiety Level','addiction_level':'Addiction Level',
}

# Light plotly theme
PLOT_THEME = dict(
    template='plotly_white',
    paper_bgcolor='rgba(0,0,0,0)',
    plot_bgcolor='rgba(248,247,255,0.5)',
    font=dict(family='Plus Jakarta Sans', color='#3b2f6b'),
    margin=dict(l=10, r=10, t=30, b=10),
)

# ── Load & train ───────────────────────────────────────────────────────────────
@st.cache_data
def load_data():
    df = pd.read_csv('Teen_Mental_Health_Dataset.csv')
    return df

@st.cache_resource
def train_model(df):
    df_maj = df[df.depression_label == 0]
    df_min = df[df.depression_label == 1]
    df_min_up = resample(df_min, replace=True, n_samples=300, random_state=42)
    df_bal = pd.concat([df_maj, df_min_up])
    X = df_bal.drop('depression_label', axis=1)
    y = df_bal['depression_label']
    num_pipe = Pipeline([('imp', SimpleImputer(strategy='mean')), ('sc', StandardScaler())])
    cat_pipe = Pipeline([('imp', SimpleImputer(strategy='most_frequent')), ('enc', OneHotEncoder(handle_unknown='ignore'))])
    pre = ColumnTransformer([('num', num_pipe, NUMERICAL_COLS), ('cat', cat_pipe, CATEGORICAL_COLS)])
    mdl = Pipeline([('pre', pre), ('clf', RandomForestClassifier(n_estimators=200, random_state=42, class_weight='balanced'))])
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    mdl.fit(X_train, y_train)
    y_pred = mdl.predict(X_test)
    metrics = {
        'accuracy': accuracy_score(y_test, y_pred),
        'cm': confusion_matrix(y_test, y_pred),
        'report': classification_report(y_test, y_pred, output_dict=True),
    }
    ohe_feats = mdl.named_steps['pre'].named_transformers_['cat'].named_steps['enc'].get_feature_names_out(CATEGORICAL_COLS)
    feat_names = NUMERICAL_COLS + list(ohe_feats)
    importances = mdl.named_steps['clf'].feature_importances_
    feat_imp = pd.DataFrame({'feature': feat_names, 'importance': importances}).sort_values('importance', ascending=False).head(12)
    feat_imp['label'] = feat_imp['feature'].apply(lambda x: LABEL_MAP.get(x, x.replace('_',' ').title()))
    return mdl, metrics, feat_imp

df = load_data()
df_display = df.copy()
df_display['depression_label'] = df_display['depression_label'].map({0:'No Depression', 1:'Depression'})
model, model_metrics, feat_imp = train_model(df)

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style='text-align:center; padding:1rem 0 0.8rem'>
        <div style='font-size:2.4rem'>🧠</div>
        <div style='font-family:"Plus Jakarta Sans",sans-serif; font-size:1.05rem; font-weight:800; color:#1e1245;'>
            Teen Mental Health
        </div>
        <div style='font-size:0.7rem; color:#9585c4; margin-top:3px;'>AI Analysis Dashboard · 1,200 records</div>
    </div>
    """, unsafe_allow_html=True)
    st.divider()
    st.markdown("**Filters**")
    age_range  = st.slider("Age range", 13, 19, (13, 19))
    genders    = st.multiselect("Gender", ["male","female"], default=["male","female"])
    platforms  = st.multiselect("Platform", ["Instagram","TikTok","Both"], default=["Instagram","TikTok","Both"])
    soc_levels = st.multiselect("Social Interaction", ["low","medium","high"], default=["low","medium","high"])
    st.divider()
    st.markdown(f"""
    <div style='font-size:0.72rem; color:#9585c4; line-height:2'>
        <b style='color:#7c3aed'>Model</b> · Random Forest<br>
        <b style='color:#7c3aed'>Accuracy</b> · {model_metrics['accuracy']*100:.1f}%<br>
        <b style='color:#7c3aed'>Trees</b> · 200<br>
        <b style='color:#7c3aed'>Balancing</b> · Upsample + class_weight
    </div>
    """, unsafe_allow_html=True)

# ── Filter ─────────────────────────────────────────────────────────────────────
fdf = df_display[
    df_display['age'].between(*age_range) &
    df_display['gender'].isin(genders) &
    df_display['platform_usage'].isin(platforms) &
    df_display['social_interaction_level'].isin(soc_levels)
]
if fdf.empty:
    st.warning("No data matches the current filters.")
    st.stop()

# ── Light chart color palette ──────────────────────────────────────────────────
PURPLE   = '#7c3aed'
PINK     = '#db2777'
VIOLET   = '#8b5cf6'
LAVENDER = '#c4b5fd'
TEAL     = '#0891b2'
AMBER    = '#d97706'
GREEN    = '#16a34a'
RED      = '#dc2626'
MALE_C   = '#7c3aed'
FEMALE_C = '#db2777'

# ── Tabs ───────────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "📊  Overview", "🔗  Correlations", "🧩  Demographics",
    "⚠️  Depression", "🤖  Predict"
])

# ════════════════════════════════════
# TAB 1 — OVERVIEW
# ════════════════════════════════════
with tab1:
    st.markdown('<div class="page-title">Dataset <span>Overview</span></div>', unsafe_allow_html=True)
    st.markdown('<div class="page-sub">Key statistics across filtered records</div>', unsafe_allow_html=True)

    c1,c2,c3,c4,c5 = st.columns(5)
    dep_pct = (fdf['depression_label']=='Depression').mean()*100
    c1.metric("Records", f"{len(fdf):,}")
    c2.metric("Avg Sleep", f"{fdf['sleep_hours'].mean():.1f} hrs")
    c3.metric("Avg Social Media", f"{fdf['daily_social_media_hours'].mean():.1f} hrs/day")
    c4.metric("Avg Stress", f"{fdf['stress_level'].mean():.1f} / 10")
    c5.metric("Depression Rate", f"{dep_pct:.1f}%")

    col_a, col_b = st.columns(2)
    with col_a:
        st.markdown('<div class="sec-hdr">Metric Distribution by Gender</div>', unsafe_allow_html=True)
        metric = st.selectbox("Metric", NUMERICAL_COLS, format_func=lambda x: LABEL_MAP[x], key='dist_m')
        fig = px.histogram(fdf, x=metric, color='gender', barmode='overlay', nbins=22,
                           color_discrete_map={'male': MALE_C, 'female': FEMALE_C}, opacity=0.72,
                           labels={metric: LABEL_MAP[metric]})
        fig.update_layout(**PLOT_THEME, height=300, legend_title_text='Gender')
        fig.update_traces(marker_line_width=0)
        st.plotly_chart(fig, use_container_width=True)

    with col_b:
        st.markdown('<div class="sec-hdr">Average Scores by Platform</div>', unsafe_allow_html=True)
        m_sel = st.multiselect("Compare", NUMERICAL_COLS,
                               default=['stress_level','anxiety_level','sleep_hours'],
                               format_func=lambda x: LABEL_MAP[x], key='plat_m')
        agg = fdf.groupby('platform_usage')[NUMERICAL_COLS].mean().reset_index()
        sub = agg.melt('platform_usage', value_vars=m_sel, var_name='metric', value_name='value')
        sub['label'] = sub['metric'].map(LABEL_MAP)
        fig2 = px.bar(sub, x='platform_usage', y='value', color='label', barmode='group',
                      labels={'platform_usage':'Platform','value':'Average','label':'Metric'},
                      color_discrete_sequence=['#7c3aed','#db2777','#0891b2','#d97706','#16a34a'])
        fig2.update_layout(**PLOT_THEME, height=300, legend_title_text='Metric')
        st.plotly_chart(fig2, use_container_width=True)

    with st.expander("🔍 Raw data preview"):
        st.dataframe(fdf.head(60), use_container_width=True)

# ════════════════════════════════════
# TAB 2 — CORRELATIONS
# ════════════════════════════════════
with tab2:
    st.markdown('<div class="page-title">Correlation <span>Analysis</span></div>', unsafe_allow_html=True)
    st.markdown('<div class="page-sub">Relationships between numeric features</div>', unsafe_allow_html=True)

    col_a, col_b = st.columns([1.3, 1])
    with col_a:
        st.markdown('<div class="sec-hdr">Correlation Heatmap</div>', unsafe_allow_html=True)
        corr = fdf[NUMERICAL_COLS].corr()
        labs = [LABEL_MAP[c] for c in corr.columns]
        fig = go.Figure(go.Heatmap(
            z=corr.values, x=labs, y=labs,
            colorscale=[[0,'#db2777'],[0.5,'#f5f3ff'],[1,'#7c3aed']],
            zmid=0, text=corr.values.round(2), texttemplate='%{text}',
            hovertemplate='%{x} × %{y}: %{z:.2f}<extra></extra>',
            colorbar=dict(tickfont=dict(color='#3b2f6b'), title=dict(font=dict(color='#3b2f6b')))
        ))
        fig.update_layout(**PLOT_THEME, height=460, xaxis=dict(tickangle=-35))
        st.plotly_chart(fig, use_container_width=True)

    with col_b:
        st.markdown('<div class="sec-hdr">Scatter Explorer</div>', unsafe_allow_html=True)
        x_ax = st.selectbox("X axis", NUMERICAL_COLS, index=0, format_func=lambda x: LABEL_MAP[x], key='sx')
        y_ax = st.selectbox("Y axis", NUMERICAL_COLS, index=2, format_func=lambda x: LABEL_MAP[x], key='sy')
        col_by = st.selectbox("Colour by", ['gender','platform_usage','social_interaction_level','depression_label'], key='sc')
        fig3 = px.scatter(fdf, x=x_ax, y=y_ax, color=col_by, opacity=0.6, trendline='ols',
                          labels={x_ax: LABEL_MAP[x_ax], y_ax: LABEL_MAP[y_ax]},
                          color_discrete_sequence=['#7c3aed','#db2777','#0891b2','#d97706'])
        fig3.update_layout(**PLOT_THEME, height=360)
        st.plotly_chart(fig3, use_container_width=True)
        r = fdf[[x_ax, y_ax]].corr().iloc[0,1]
        dir_ = 'positive' if r > 0 else 'negative'
        str_ = 'strong' if abs(r)>0.5 else ('moderate' if abs(r)>0.3 else 'weak')
        st.info(f"**Pearson r = {r:.3f}** — {str_} {dir_} correlation")

# ════════════════════════════════════
# TAB 3 — DEMOGRAPHICS
# ════════════════════════════════════
with tab3:
    st.markdown('<div class="page-title">Demographics & <span>Behaviour</span></div>', unsafe_allow_html=True)
    st.markdown('<div class="page-sub">Distribution of population characteristics</div>', unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    with c1:
        st.markdown('<div class="sec-hdr">Gender Split</div>', unsafe_allow_html=True)
        gc = fdf['gender'].value_counts().reset_index()
        fig = px.pie(gc, names='gender', values='count', hole=0.5,
                     color_discrete_map={'male': MALE_C, 'female': FEMALE_C})
        fig.update_layout(**PLOT_THEME, height=260)
        st.plotly_chart(fig, use_container_width=True)

        st.markdown('<div class="sec-hdr">Platform Usage</div>', unsafe_allow_html=True)
        pc = fdf['platform_usage'].value_counts().reset_index()
        fig2 = px.bar(pc, x='platform_usage', y='count', color='platform_usage',
                      color_discrete_sequence=[AMBER, TEAL, VIOLET],
                      labels={'platform_usage':'Platform','count':'Count'})
        fig2.update_layout(**PLOT_THEME, height=240, showlegend=False)
        st.plotly_chart(fig2, use_container_width=True)

    with c2:
        st.markdown('<div class="sec-hdr">Age Distribution by Social Interaction</div>', unsafe_allow_html=True)
        fig3 = px.violin(fdf, x='social_interaction_level', y='age', color='social_interaction_level',
                         box=True, points='suspectedoutliers',
                         category_orders={'social_interaction_level':['low','medium','high']},
                         color_discrete_sequence=[RED, AMBER, GREEN],
                         labels={'social_interaction_level':'Social Level','age':'Age'})
        fig3.update_layout(**PLOT_THEME, height=290, showlegend=False)
        st.plotly_chart(fig3, use_container_width=True)

        st.markdown('<div class="sec-hdr">Social Media Hours by Age Group</div>', unsafe_allow_html=True)
        fdf2 = fdf.copy()
        fdf2['age_group'] = pd.cut(fdf2['age'], bins=[12,14,16,19], labels=['13–14','15–16','17–19'])
        bd = fdf2.groupby(['age_group','platform_usage'])['daily_social_media_hours'].mean().reset_index()
        fig4 = px.bar(bd, x='age_group', y='daily_social_media_hours', color='platform_usage', barmode='group',
                      color_discrete_sequence=[AMBER, TEAL, VIOLET],
                      labels={'age_group':'Age Group','daily_social_media_hours':'Avg (hrs)','platform_usage':'Platform'})
        fig4.update_layout(**PLOT_THEME, height=260)
        st.plotly_chart(fig4, use_container_width=True)

# ════════════════════════════════════
# TAB 4 — DEPRESSION ANALYSIS
# ════════════════════════════════════
with tab4:
    st.markdown('<div class="page-title">Depression <span>Analysis</span></div>', unsafe_allow_html=True)
    st.markdown('<div class="page-sub">Patterns and risk factors for depression in filtered population</div>', unsafe_allow_html=True)

    dep = fdf['depression_label'].value_counts().reset_index()
    c1, c2 = st.columns([1, 2])
    with c1:
        st.markdown('<div class="sec-hdr">Overall Labels</div>', unsafe_allow_html=True)
        fig = px.pie(dep, names='depression_label', values='count', hole=0.55,
                     color_discrete_map={'No Depression': GREEN, 'Depression': RED})
        fig.update_layout(**PLOT_THEME, height=260)
        st.plotly_chart(fig, use_container_width=True)
        dep_n = (fdf['depression_label']=='Depression').sum()
        st.metric("Depressed teens", f"{dep_n} / {len(fdf)}", delta=f"{dep_n/len(fdf)*100:.1f}%")

    with c2:
        st.markdown('<div class="sec-hdr">Key Metrics — Depressed vs Not</div>', unsafe_allow_html=True)
        cm_cols = ['stress_level','anxiety_level','sleep_hours','daily_social_media_hours','addiction_level','physical_activity']
        gm = fdf.groupby('depression_label')[cm_cols].mean().reset_index()
        gml = gm.melt('depression_label', var_name='metric', value_name='value')
        gml['label'] = gml['metric'].map(LABEL_MAP)
        fig2 = px.bar(gml, x='label', y='value', color='depression_label', barmode='group',
                      color_discrete_map={'No Depression': GREEN, 'Depression': RED},
                      labels={'label':'Metric','value':'Average','depression_label':'Group'})
        fig2.update_layout(**PLOT_THEME, height=300, xaxis_tickangle=-25, legend_title_text='')
        st.plotly_chart(fig2, use_container_width=True)

    c3, c4 = st.columns(2)
    with c3:
        st.markdown('<div class="sec-hdr">Depression Rate by Platform</div>', unsafe_allow_html=True)
        pd_dep = fdf.groupby('platform_usage').apply(
            lambda x: (x['depression_label']=='Depression').mean()*100).reset_index(name='rate')
        fig3 = px.bar(pd_dep, x='platform_usage', y='rate', color='platform_usage', text_auto='.1f',
                      color_discrete_sequence=[AMBER, TEAL, VIOLET],
                      labels={'platform_usage':'Platform','rate':'Depression Rate (%)'})
        fig3.update_layout(**PLOT_THEME, height=280, showlegend=False)
        st.plotly_chart(fig3, use_container_width=True)

    with c4:
        st.markdown('<div class="sec-hdr">Stress & Anxiety by Social Level</div>', unsafe_allow_html=True)
        sg = fdf.groupby('social_interaction_level')[['stress_level','anxiety_level']].mean().reset_index()
        sgl = sg.melt('social_interaction_level', var_name='metric', value_name='value')
        sgl['metric'] = sgl['metric'].map(LABEL_MAP)
        fig4 = px.bar(sgl, x='social_interaction_level', y='value', color='metric', barmode='group',
                      category_orders={'social_interaction_level':['low','medium','high']},
                      color_discrete_sequence=[RED, PURPLE],
                      labels={'social_interaction_level':'Social Level','value':'Average Score','metric':''})
        fig4.update_layout(**PLOT_THEME, height=280)
        st.plotly_chart(fig4, use_container_width=True)

    st.markdown('<div class="sec-hdr">Risk Profile — Parallel Coordinates</div>', unsafe_allow_html=True)
    rc = ['stress_level','anxiety_level','addiction_level','sleep_hours','daily_social_media_hours','physical_activity']
    pc_df = fdf[rc + ['depression_label']].copy()
    pc_df['dep_num'] = (pc_df['depression_label']=='Depression').astype(int)
    dims = [dict(label=LABEL_MAP[c], values=pc_df[c]) for c in rc]
    fig5 = go.Figure(go.Parcoords(
        line=dict(color=pc_df['dep_num'], colorscale=[[0, GREEN],[1, RED]],
                  showscale=True, colorbar=dict(title='Depressed', tickvals=[0,1], ticktext=['No','Yes'],
                                                tickfont=dict(color='#3b2f6b'))),
        dimensions=dims,
        labelfont=dict(color='#3b2f6b', size=11),
        tickfont=dict(color='#6d5c99', size=10),
    ))
    fig5.update_layout(**PLOT_THEME, height=340)
    st.plotly_chart(fig5, use_container_width=True)

# ════════════════════════════════════
# TAB 5 — PREDICT
# ════════════════════════════════════
with tab5:
    st.markdown('<div class="page-title">Depression Risk <span>Predictor</span></div>', unsafe_allow_html=True)
    st.markdown('<div class="page-sub">Enter a teen\'s profile to get an AI-powered depression risk assessment</div>', unsafe_allow_html=True)

    col_form, col_result = st.columns([1.1, 1])

    with col_form:
        st.markdown('<div class="sec-hdr">Profile Input</div>', unsafe_allow_html=True)
        fa, fb = st.columns(2)
        with fa:
            p_age    = st.slider("Age", 13, 19, 16)
            p_sleep  = st.slider("Sleep Hours", 4.0, 10.0, 7.5, 0.1)
            p_social = st.slider("Daily Social Media (hrs)", 1.0, 8.0, 3.0, 0.1)
            p_screen = st.slider("Screen Time Before Sleep (hrs)", 0.0, 5.0, 1.5, 0.1)
            p_academ = st.slider("Academic Performance (GPA)", 1.0, 4.0, 3.0, 0.01)
        with fb:
            p_phys    = st.slider("Physical Activity (hrs/week)", 0.0, 7.0, 2.0, 0.1)
            p_stress  = st.slider("Stress Level", 1, 10, 5)
            p_anxiety = st.slider("Anxiety Level", 1, 10, 4)
            p_addict  = st.slider("Addiction Level", 1, 10, 5)

        fc, fd, fe = st.columns(3)
        with fc:  p_gender   = st.selectbox("Gender", ["male","female"])
        with fd:  p_platform = st.selectbox("Platform", ["Instagram","TikTok","Both"])
        with fe:  p_soc_lvl  = st.selectbox("Social Interaction", ["low","medium","high"])

        predict_btn = st.button("🔮  Run Prediction", use_container_width=True)

    with col_result:
        st.markdown('<div class="sec-hdr">Prediction Result</div>', unsafe_allow_html=True)

        if predict_btn:
            input_df = pd.DataFrame([{
                'age': p_age, 'daily_social_media_hours': p_social,
                'sleep_hours': p_sleep, 'screen_time_before_sleep': p_screen,
                'academic_performance': p_academ, 'physical_activity': p_phys,
                'stress_level': p_stress, 'anxiety_level': p_anxiety,
                'addiction_level': p_addict, 'gender': p_gender,
                'platform_usage': p_platform, 'social_interaction_level': p_soc_lvl,
            }])
            pred  = model.predict(input_df)[0]
            proba = model.predict_proba(input_df)[0]
            risk_pct = proba[1] * 100
            safe_pct = proba[0] * 100

            if pred == 0:
                st.markdown(f"""
                <div class="pred-safe">
                    <div class="pred-label" style="color:#16a34a">✓ No Depression Risk</div>
                    <div class="pred-conf">Confidence: {safe_pct:.1f}%</div>
                    <span class="risk-badge" style="background:#dcfce7;color:#16a34a">LOW RISK</span>
                </div>""", unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div class="pred-risk">
                    <div class="pred-label" style="color:#dc2626">⚠ Depression Risk Detected</div>
                    <div class="pred-conf">Confidence: {risk_pct:.1f}%</div>
                    <span class="risk-badge" style="background:#ffe4e6;color:#dc2626">HIGH RISK</span>
                </div>""", unsafe_allow_html=True)

            # Gauge
            gauge_color = RED if risk_pct > 40 else AMBER if risk_pct > 20 else GREEN
            fig_gauge = go.Figure(go.Indicator(
                mode='gauge+number', value=risk_pct,
                number={'suffix':'%', 'font':{'size':28, 'color':'#1e1245', 'family':'Plus Jakarta Sans'}},
                title={'text':'Depression Risk Score', 'font':{'size':12, 'color':'#7c3aed'}},
                gauge={
                    'axis':{'range':[0,100], 'tickcolor':'#c4b5fd', 'tickfont':{'color':'#9585c4','size':10}},
                    'bar':{'color': gauge_color, 'thickness':0.25},
                    'bgcolor':'rgba(255,255,255,0.8)',
                    'bordercolor':'rgba(0,0,0,0)',
                    'steps':[
                        {'range':[0,30],  'color':'rgba(22,163,74,0.08)'},
                        {'range':[30,60], 'color':'rgba(217,119,6,0.08)'},
                        {'range':[60,100],'color':'rgba(220,38,38,0.08)'},
                    ],
                    'threshold':{'line':{'color':'#1e1245','width':2},'thickness':0.75,'value':risk_pct}
                }
            ))
            fig_gauge.update_layout(**PLOT_THEME, height=220)
            st.plotly_chart(fig_gauge, use_container_width=True)

            # Probability bar
            fig_prob = go.Figure()
            fig_prob.add_trace(go.Bar(
                x=['No Depression','Depression'], y=[safe_pct, risk_pct],
                marker_color=[GREEN, RED],
                text=[f'{safe_pct:.1f}%', f'{risk_pct:.1f}%'],
                textposition='outside',
                textfont=dict(color='#1e1245', size=13, family='Plus Jakarta Sans'),
            ))
            fig_prob.update_layout(**PLOT_THEME, height=200,
                                   yaxis=dict(range=[0,118], showgrid=False, showticklabels=False),
                                   xaxis=dict(showgrid=False))
            st.plotly_chart(fig_prob, use_container_width=True)

        else:
            st.markdown("""
            <div class="await-card">
                <div style='font-size:2.8rem; margin-bottom:0.5rem'>🔮</div>
                <div style='font-family:"Plus Jakarta Sans",sans-serif; font-size:1rem; font-weight:700; color:#7c3aed;'>
                    Awaiting Input
                </div>
                <div style='font-size:0.8rem; color:#9585c4; margin-top:0.3rem;'>
                    Adjust the sliders and click Run Prediction
                </div>
            </div>""", unsafe_allow_html=True)

    # Feature importance
    st.markdown('<div class="sec-hdr">Feature Importance — What Drives the Model</div>', unsafe_allow_html=True)
    c_imp1, c_imp2 = st.columns([1.6, 1])
    with c_imp1:
        fig_imp = px.bar(feat_imp, x='importance', y='label', orientation='h',
                         color='importance',
                         color_continuous_scale=['#ede9fe','#8b5cf6','#7c3aed','#5b21b6'],
                         labels={'importance':'Importance Score','label':'Feature'})
        fig_imp.update_layout(**PLOT_THEME, height=340, coloraxis_showscale=False,
                              yaxis=dict(autorange='reversed'))
        st.plotly_chart(fig_imp, use_container_width=True)

    with c_imp2:
        st.markdown('<div class="sec-hdr">Model Performance</div>', unsafe_allow_html=True)
        acc = model_metrics['accuracy']
        rep = model_metrics['report']
        st.metric("Accuracy", f"{acc*100:.1f}%")

        perf_data = []
        for lbl, name in [('0','No Depression'),('1','Depression')]:
            if lbl in rep:
                perf_data.append({'Class':name, 'Precision':rep[lbl]['precision'],
                                  'Recall':rep[lbl]['recall'], 'F1':rep[lbl]['f1-score']})
        if perf_data:
            pdf  = pd.DataFrame(perf_data)
            pdfl = pdf.melt('Class', var_name='Metric', value_name='Score')
            fig_perf = px.bar(pdfl, x='Metric', y='Score', color='Class', barmode='group',
                              color_discrete_map={'No Depression': GREEN, 'Depression': RED},
                              text_auto='.2f')
            fig_perf.update_layout(**PLOT_THEME, height=240,
                                   yaxis=dict(range=[0,1.2]), legend_title_text='')
            st.plotly_chart(fig_perf, use_container_width=True)

        cm = model_metrics['cm']
        fig_cm = px.imshow(cm, text_auto=True,
                           x=['Pred: No Dep','Pred: Dep'],
                           y=['Act: No Dep','Act: Dep'],
                           color_continuous_scale=['#f5f3ff','#c4b5fd','#7c3aed'])
        fig_cm.update_layout(**PLOT_THEME, height=190, coloraxis_showscale=False)
        st.plotly_chart(fig_cm, use_container_width=True)