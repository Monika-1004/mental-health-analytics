import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
accuracy_score,
classification_report,
confusion_matrix
)

# =========================
#
# Load Dataset
#
# =========================

df = pd.read_csv('Teen_Mental_Health_Dataset.csv')

print('Dataset Shape:', df.shape)
print('\nFirst 5 Rows:\n')
print(df.head())

# =========================
#
# Features and Target
#
# =========================

X = df.drop('depression_label', axis=1)
y = df['depression_label']

# =========================
#
# Column Types
#
# =========================

categorical_cols = X.select_dtypes(include=['object']).columns.tolist()
numerical_cols = X.select_dtypes(exclude=['object']).columns.tolist()

print('\nCategorical Columns:', categorical_cols)
print('Numerical Columns:', numerical_cols)

# =========================
#
# Preprocessing
#
# =========================

numeric_transformer = Pipeline([
('imputer', SimpleImputer(strategy='mean')),
('scaler', StandardScaler())
])

categorical_transformer = Pipeline([
('imputer', SimpleImputer(strategy='most_frequent')),
('encoder', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer([
('num', numeric_transformer, numerical_cols),
('cat', categorical_transformer, categorical_cols)
])

# =========================
#
# Train Test Split
#
# =========================

X_train, X_test, y_train, y_test = train_test_split(
X,
y,
test_size=0.2,
random_state=42,
stratify=y
)

# =========================
#
# Model Pipeline
#
# =========================

model = Pipeline([
('preprocessor', preprocessor),
('classifier', RandomForestClassifier(
n_estimators=200,
random_state=42
))
])

# =========================
#
# Train Model
#
# =========================

print('\nTraining Model...')
model.fit(X_train, y_train)

# =========================
#
# Predictions
#
# =========================

y_pred = model.predict(X_test)

# =========================
#
# Evaluation
#
# =========================

accuracy = accuracy_score(y_test, y_pred)

print('\n=========================')
print('MODEL EVALUATION')
print('=========================')

print(f'\nAccuracy Score: {accuracy:.4f}')

print('\nClassification Report:\n')
print(classification_report(y_test, y_pred))

print('\nConfusion Matrix:\n')
print(confusion_matrix(y_test, y_pred))

# =========================
#
# Save Model
#
# =========================

joblib.dump(model, 'teen_mental_health_model.pkl')

print('\nModel saved as teen_mental_health_model.pkl')

